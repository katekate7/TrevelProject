<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/api/cities' => [[['_route' => 'city_search', '_controller' => 'App\\Controller\\Api\\CityController::search'], null, ['GET' => 0], null, false, false, null]],
        '/api/destinations' => [[['_route' => 'get_destinations', '_controller' => 'App\\Controller\\Api\\DestinationController::getDestinations'], null, ['GET' => 0], null, true, false, null]],
        '/api/items' => [
            [['_route' => 'api_items_list', '_controller' => 'App\\Controller\\Api\\ItemController::list'], null, ['GET' => 0], null, false, false, null],
            [['_route' => 'api_items_create', '_controller' => 'App\\Controller\\Api\\ItemController::create'], null, ['POST' => 0], null, false, false, null],
        ],
        '/api/item-requests' => [
            [['_route' => 'api_item_requests_create', '_controller' => 'App\\Controller\\Api\\ItemRequestController::create'], null, ['POST' => 0], null, false, false, null],
            [['_route' => 'api_item_requests_list', '_controller' => 'App\\Controller\\Api\\ItemRequestController::list'], null, ['GET' => 0], null, false, false, null],
        ],
        '/api/trips' => [[['_route' => 'api_trips_list', '_controller' => 'App\\Controller\\Api\\TripController::list'], null, ['GET' => 0], null, false, false, null]],
        '/api/trips/add' => [[['_route' => 'api_trips_add', '_controller' => 'App\\Controller\\Api\\TripController::addTrip'], null, ['POST' => 0], null, false, false, null]],
        '/api/users/me' => [[['_route' => 'api_users_me', '_controller' => 'App\\Controller\\Api\\UserController::me'], null, ['GET' => 0], null, false, false, null]],
        '/api/users/register' => [[['_route' => 'api_users_register', '_controller' => 'App\\Controller\\Api\\UserController::register'], null, ['POST' => 0], null, false, false, null]],
        '/api/users/forgot-password' => [[['_route' => 'api_users_forgot_password', '_controller' => 'App\\Controller\\Api\\UserController::forgotPassword'], null, ['POST' => 0], null, false, false, null]],
        '/api/users/create-admin' => [[['_route' => 'api_users_create_admin', '_controller' => 'App\\Controller\\Api\\UserController::createAdmin'], null, ['POST' => 0], null, false, false, null]],
        '/api/users' => [
            [['_route' => 'api_users_list', '_controller' => 'App\\Controller\\Api\\UserController::list'], null, ['GET' => 0], null, false, false, null],
            [['_route' => 'api_users_create', '_controller' => 'App\\Controller\\Api\\UserController::create'], null, ['POST' => 0], null, false, false, null],
        ],
        '/' => [[['_route' => 'redirect_to_login', '_controller' => 'App\\Controller\\RedirectController::index'], null, ['GET' => 0], null, false, false, null]],
        '/trip' => [[['_route' => 'app_trip_page', '_controller' => 'App\\Controller\\TripPageController::index'], null, null, null, false, false, null]],
        '/api/login' => [[['_route' => 'api_login'], null, ['POST' => 0], null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/api/(?'
                    .'|destinations/(?'
                        .'|([^/]++)(*:39)'
                        .'|add(*:49)'
                    .')'
                    .'|item(?'
                        .'|s/([^/]++)(?'
                            .'|(*:77)'
                            .'|/toggle/([^/]++)(*:100)'
                        .')'
                        .'|\\-requests/([^/]++)(?'
                            .'|(*:131)'
                        .')'
                    .')'
                    .'|trips/(?'
                        .'|(\\d+)(?'
                            .'|(*:158)'
                        .')'
                        .'|([^/]++)/(?'
                            .'|sightseeings(*:191)'
                            .'|weather(?'
                                .'|/update(*:216)'
                                .'|(*:224)'
                            .')'
                            .'|route(*:238)'
                            .'|items(?'
                                .'|(*:254)'
                                .'|/([^/]++)(*:271)'
                            .')'
                        .')'
                        .'|(\\d+)/places(?'
                            .'|(*:296)'
                        .')'
                        .'|(\\d+)/route(?'
                            .'|(*:319)'
                        .')'
                    .')'
                    .'|users/(?'
                        .'|([^/]++)(?'
                            .'|(*:349)'
                            .'|/reset\\-password(*:373)'
                        .')'
                        .'|reset\\-password\\-token/([^/]++)(*:413)'
                    .')'
                .')'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        39 => [[['_route' => 'get_destination', '_controller' => 'App\\Controller\\Api\\DestinationController::getDestination'], ['id'], ['GET' => 0], null, false, true, null]],
        49 => [[['_route' => 'add_destination', '_controller' => 'App\\Controller\\Api\\DestinationController::addDestination'], [], ['POST' => 0], null, false, false, null]],
        77 => [
            [['_route' => 'api_items_update', '_controller' => 'App\\Controller\\Api\\ItemController::update'], ['id'], ['PATCH' => 0], null, false, true, null],
            [['_route' => 'api_items_delete', '_controller' => 'App\\Controller\\Api\\ItemController::delete'], ['id'], ['DELETE' => 0], null, false, true, null],
        ],
        100 => [[['_route' => 'api_items_toggle', '_controller' => 'App\\Controller\\Api\\ItemController::toggleTaken'], ['itemId', 'tripId'], ['POST' => 0], null, false, true, null]],
        131 => [
            [['_route' => 'api_item_requests_review', '_controller' => 'App\\Controller\\Api\\ItemRequestController::review'], ['id'], ['PATCH' => 0], null, false, true, null],
            [['_route' => 'api_item_requests_delete', '_controller' => 'App\\Controller\\Api\\ItemRequestController::delete'], ['id'], ['DELETE' => 0], null, false, true, null],
        ],
        158 => [
            [['_route' => 'api_trips_delete', '_controller' => 'App\\Controller\\Api\\TripController::deleteTrip'], ['id'], ['DELETE' => 0], null, false, true, null],
            [['_route' => 'api_trips_get', '_controller' => 'App\\Controller\\Api\\TripController::getTrip'], ['id'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_trips_update', '_controller' => 'App\\Controller\\Api\\TripController::updateTrip'], ['id'], ['PATCH' => 0], null, false, true, null],
        ],
        191 => [[['_route' => 'api_trips_sightseeings_update', '_controller' => 'App\\Controller\\Api\\TripController::updateSightseeings'], ['id'], ['PATCH' => 0], null, false, false, null]],
        216 => [[['_route' => 'api_trips_weather_update', '_controller' => 'App\\Controller\\Api\\TripController::updateWeather'], ['id'], ['PATCH' => 0], null, false, false, null]],
        224 => [[['_route' => 'api_trips_weather', '_controller' => 'App\\Controller\\Api\\TripController::getWeather'], ['id'], ['GET' => 0], null, false, false, null]],
        238 => [[['_route' => 'api_trips_route_get', '_controller' => 'App\\Controller\\Api\\TripController::getRoute'], ['id'], ['GET' => 0], null, false, false, null]],
        254 => [[['_route' => 'api_trip_items_list', '_controller' => 'App\\Controller\\Api\\TripItemController::list'], ['tripId'], ['GET' => 0], null, false, false, null]],
        271 => [[['_route' => 'api_trip_items_toggle', '_controller' => 'App\\Controller\\Api\\TripItemController::toggle'], ['tripId', 'itemId'], ['POST' => 0], null, false, true, null]],
        296 => [
            [['_route' => 'api_trip_places_list', '_controller' => 'App\\Controller\\Api\\TripPlaceController::list'], ['trip'], ['GET' => 0], null, false, false, null],
            [['_route' => 'api_trip_places_save', '_controller' => 'App\\Controller\\Api\\TripPlaceController::save'], ['trip'], ['POST' => 0], null, false, false, null],
        ],
        319 => [
            [['_route' => 'api_trip_route_get', '_controller' => 'App\\Controller\\Api\\TripRouteController::get'], ['trip'], ['GET' => 0], null, false, false, null],
            [['_route' => 'api_trip_route_save', '_controller' => 'App\\Controller\\Api\\TripRouteController::save'], ['trip'], ['POST' => 0], null, false, false, null],
        ],
        349 => [
            [['_route' => 'api_users_update', '_controller' => 'App\\Controller\\Api\\UserController::update'], ['id'], ['PUT' => 0], null, false, true, null],
            [['_route' => 'api_users_delete', '_controller' => 'App\\Controller\\Api\\UserController::delete'], ['id'], ['DELETE' => 0], null, false, true, null],
        ],
        373 => [[['_route' => 'api_users_reset_password', '_controller' => 'App\\Controller\\Api\\UserController::resetPassword'], ['id'], ['POST' => 0], null, false, false, null]],
        413 => [
            [['_route' => 'api_users_reset_password_with_token', '_controller' => 'App\\Controller\\Api\\UserController::resetPasswordWithToken'], ['token'], ['POST' => 0], null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
