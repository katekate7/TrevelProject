<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/_wdt/styles' => [[['_route' => '_wdt_stylesheet', '_controller' => 'web_profiler.controller.profiler::toolbarStylesheetAction'], null, null, null, false, false, null]],
        '/_profiler' => [[['_route' => '_profiler_home', '_controller' => 'web_profiler.controller.profiler::homeAction'], null, null, null, true, false, null]],
        '/_profiler/search' => [[['_route' => '_profiler_search', '_controller' => 'web_profiler.controller.profiler::searchAction'], null, null, null, false, false, null]],
        '/_profiler/search_bar' => [[['_route' => '_profiler_search_bar', '_controller' => 'web_profiler.controller.profiler::searchBarAction'], null, null, null, false, false, null]],
        '/_profiler/phpinfo' => [[['_route' => '_profiler_phpinfo', '_controller' => 'web_profiler.controller.profiler::phpinfoAction'], null, null, null, false, false, null]],
        '/_profiler/xdebug' => [[['_route' => '_profiler_xdebug', '_controller' => 'web_profiler.controller.profiler::xdebugAction'], null, null, null, false, false, null]],
        '/_profiler/open' => [[['_route' => '_profiler_open_file', '_controller' => 'web_profiler.controller.profiler::openAction'], null, null, null, false, false, null]],
        '/api/cities' => [[['_route' => 'city_search', '_controller' => 'App\\Controller\\Api\\CityController::search'], null, ['GET' => 0], null, false, false, null]],
        '/api/destinations' => [[['_route' => 'get_destinations', '_controller' => 'App\\Controller\\Api\\DestinationController::getDestinations'], null, ['GET' => 0], null, true, false, null]],
        '/api/items' => [
            [['_route' => 'api_items_list', '_controller' => 'App\\Controller\\Api\\ItemController::list'], null, ['GET' => 0], null, false, false, null],
            [['_route' => 'api_items_create', '_controller' => 'App\\Controller\\Api\\ItemController::create'], null, ['POST' => 0], null, false, false, null],
        ],
        '/api/item-requests' => [
            [['_route' => 'api_item_requests_create', '_controller' => 'App\\Controller\\Api\\ItemRequestController::create'], null, ['POST' => 0], null, false, false, null],
            [['_route' => 'api_item_requests_list', '_controller' => 'App\\Controller\\Api\\ItemRequestController::list'], null, ['GET' => 0], null, false, false, null],
        ],
        '/api/trips' => [[['_route' => 'api_trips_list', '_controller' => 'App\\Controller\\Api\\TripController::list'], null, ['GET' => 0], null, false, false, null]],
        '/api/trips/add' => [[['_route' => 'api_trips_add', '_controller' => 'App\\Controller\\Api\\TripController::addTrip'], null, ['POST' => 0], null, false, false, null]],
        '/api/users/me' => [[['_route' => 'api_users_me', '_controller' => 'App\\Controller\\Api\\UserController::me'], null, ['GET' => 0], null, false, false, null]],
        '/api/users/register' => [[['_route' => 'api_users_register', '_controller' => 'App\\Controller\\Api\\UserController::register'], null, ['POST' => 0], null, false, false, null]],
        '/api/users/forgot-password' => [[['_route' => 'api_users_forgot_password', '_controller' => 'App\\Controller\\Api\\UserController::forgotPassword'], null, ['POST' => 0], null, false, false, null]],
        '/api/users/create-admin' => [[['_route' => 'api_users_create_admin', '_controller' => 'App\\Controller\\Api\\UserController::createAdmin'], null, ['POST' => 0], null, false, false, null]],
        '/api/users' => [
            [['_route' => 'api_users_list', '_controller' => 'App\\Controller\\Api\\UserController::list'], null, ['GET' => 0], null, false, false, null],
            [['_route' => 'api_users_create', '_controller' => 'App\\Controller\\Api\\UserController::create'], null, ['POST' => 0], null, false, false, null],
        ],
        '/' => [[['_route' => 'redirect_to_login', '_controller' => 'App\\Controller\\RedirectController::index'], null, ['GET' => 0], null, false, false, null]],
        '/trip' => [[['_route' => 'app_trip_page', '_controller' => 'App\\Controller\\TripPageController::index'], null, null, null, false, false, null]],
        '/api/login' => [[['_route' => 'api_login'], null, ['POST' => 0], null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/_(?'
                    .'|error/(\\d+)(?:\\.([^/]++))?(*:38)'
                    .'|wdt/([^/]++)(*:57)'
                    .'|profiler/(?'
                        .'|font/([^/\\.]++)\\.woff2(*:98)'
                        .'|([^/]++)(?'
                            .'|/(?'
                                .'|search/results(*:134)'
                                .'|router(*:148)'
                                .'|exception(?'
                                    .'|(*:168)'
                                    .'|\\.css(*:181)'
                                .')'
                            .')'
                            .'|(*:191)'
                        .')'
                    .')'
                .')'
                .'|/api/(?'
                    .'|destinations/(?'
                        .'|([^/]++)(*:234)'
                        .'|add(*:245)'
                    .')'
                    .'|item(?'
                        .'|s/([^/]++)(?'
                            .'|(*:274)'
                            .'|/toggle/([^/]++)(*:298)'
                        .')'
                        .'|\\-requests/([^/]++)(?'
                            .'|(*:329)'
                        .')'
                    .')'
                    .'|trips/(?'
                        .'|(\\d+)(?'
                            .'|(*:356)'
                        .')'
                        .'|([^/]++)/(?'
                            .'|sightseeings(*:389)'
                            .'|weather(?'
                                .'|/update(*:414)'
                                .'|(*:422)'
                            .')'
                            .'|route(*:436)'
                            .'|items(?'
                                .'|(*:452)'
                                .'|/([^/]++)(*:469)'
                            .')'
                        .')'
                        .'|(\\d+)/places(?'
                            .'|(*:494)'
                        .')'
                        .'|(\\d+)/route(?'
                            .'|(*:517)'
                        .')'
                    .')'
                    .'|users/(?'
                        .'|([^/]++)(?'
                            .'|(*:547)'
                            .'|/reset\\-password(*:571)'
                        .')'
                        .'|reset\\-password\\-token/([^/]++)(*:611)'
                    .')'
                .')'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        38 => [[['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null]],
        57 => [[['_route' => '_wdt', '_controller' => 'web_profiler.controller.profiler::toolbarAction'], ['token'], null, null, false, true, null]],
        98 => [[['_route' => '_profiler_font', '_controller' => 'web_profiler.controller.profiler::fontAction'], ['fontName'], null, null, false, false, null]],
        134 => [[['_route' => '_profiler_search_results', '_controller' => 'web_profiler.controller.profiler::searchResultsAction'], ['token'], null, null, false, false, null]],
        148 => [[['_route' => '_profiler_router', '_controller' => 'web_profiler.controller.router::panelAction'], ['token'], null, null, false, false, null]],
        168 => [[['_route' => '_profiler_exception', '_controller' => 'web_profiler.controller.exception_panel::body'], ['token'], null, null, false, false, null]],
        181 => [[['_route' => '_profiler_exception_css', '_controller' => 'web_profiler.controller.exception_panel::stylesheet'], ['token'], null, null, false, false, null]],
        191 => [[['_route' => '_profiler', '_controller' => 'web_profiler.controller.profiler::panelAction'], ['token'], null, null, false, true, null]],
        234 => [[['_route' => 'get_destination', '_controller' => 'App\\Controller\\Api\\DestinationController::getDestination'], ['id'], ['GET' => 0], null, false, true, null]],
        245 => [[['_route' => 'add_destination', '_controller' => 'App\\Controller\\Api\\DestinationController::addDestination'], [], ['POST' => 0], null, false, false, null]],
        274 => [
            [['_route' => 'api_items_update', '_controller' => 'App\\Controller\\Api\\ItemController::update'], ['id'], ['PATCH' => 0], null, false, true, null],
            [['_route' => 'api_items_delete', '_controller' => 'App\\Controller\\Api\\ItemController::delete'], ['id'], ['DELETE' => 0], null, false, true, null],
        ],
        298 => [[['_route' => 'api_items_toggle', '_controller' => 'App\\Controller\\Api\\ItemController::toggleTaken'], ['itemId', 'tripId'], ['POST' => 0], null, false, true, null]],
        329 => [
            [['_route' => 'api_item_requests_review', '_controller' => 'App\\Controller\\Api\\ItemRequestController::review'], ['id'], ['PATCH' => 0], null, false, true, null],
            [['_route' => 'api_item_requests_delete', '_controller' => 'App\\Controller\\Api\\ItemRequestController::delete'], ['id'], ['DELETE' => 0], null, false, true, null],
        ],
        356 => [
            [['_route' => 'api_trips_delete', '_controller' => 'App\\Controller\\Api\\TripController::deleteTrip'], ['id'], ['DELETE' => 0], null, false, true, null],
            [['_route' => 'api_trips_get', '_controller' => 'App\\Controller\\Api\\TripController::getTrip'], ['id'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_trips_update', '_controller' => 'App\\Controller\\Api\\TripController::updateTrip'], ['id'], ['PATCH' => 0], null, false, true, null],
        ],
        389 => [[['_route' => 'api_trips_sightseeings_update', '_controller' => 'App\\Controller\\Api\\TripController::updateSightseeings'], ['id'], ['PATCH' => 0], null, false, false, null]],
        414 => [[['_route' => 'api_trips_weather_update', '_controller' => 'App\\Controller\\Api\\TripController::updateWeather'], ['id'], ['PATCH' => 0], null, false, false, null]],
        422 => [[['_route' => 'api_trips_weather', '_controller' => 'App\\Controller\\Api\\TripController::getWeather'], ['id'], ['GET' => 0], null, false, false, null]],
        436 => [[['_route' => 'api_trips_route_get', '_controller' => 'App\\Controller\\Api\\TripController::getRoute'], ['id'], ['GET' => 0], null, false, false, null]],
        452 => [[['_route' => 'api_trip_items_list', '_controller' => 'App\\Controller\\Api\\TripItemController::list'], ['tripId'], ['GET' => 0], null, false, false, null]],
        469 => [[['_route' => 'api_trip_items_toggle', '_controller' => 'App\\Controller\\Api\\TripItemController::toggle'], ['tripId', 'itemId'], ['POST' => 0], null, false, true, null]],
        494 => [
            [['_route' => 'api_trip_places_list', '_controller' => 'App\\Controller\\Api\\TripPlaceController::list'], ['trip'], ['GET' => 0], null, false, false, null],
            [['_route' => 'api_trip_places_save', '_controller' => 'App\\Controller\\Api\\TripPlaceController::save'], ['trip'], ['POST' => 0], null, false, false, null],
        ],
        517 => [
            [['_route' => 'api_trip_route_get', '_controller' => 'App\\Controller\\Api\\TripRouteController::get'], ['trip'], ['GET' => 0], null, false, false, null],
            [['_route' => 'api_trip_route_save', '_controller' => 'App\\Controller\\Api\\TripRouteController::save'], ['trip'], ['POST' => 0], null, false, false, null],
        ],
        547 => [
            [['_route' => 'api_users_update', '_controller' => 'App\\Controller\\Api\\UserController::update'], ['id'], ['PUT' => 0], null, false, true, null],
            [['_route' => 'api_users_delete', '_controller' => 'App\\Controller\\Api\\UserController::delete'], ['id'], ['DELETE' => 0], null, false, true, null],
        ],
        571 => [[['_route' => 'api_users_reset_password', '_controller' => 'App\\Controller\\Api\\UserController::resetPassword'], ['id'], ['POST' => 0], null, false, false, null]],
        611 => [
            [['_route' => 'api_users_reset_password_with_token', '_controller' => 'App\\Controller\\Api\\UserController::resetPasswordWithToken'], ['token'], ['POST' => 0], null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
